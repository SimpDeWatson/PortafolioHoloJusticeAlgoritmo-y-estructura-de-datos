================================================================================
  CAPÍTULO 01 - ALGORITMOS Y ESTRUCTURA DE DATOS
  Universidad Peruana Los Andes
  Actividades resueltas - Arreglos Unidimensionales y Bidimensionales
================================================================================

CONTENIDO DEL ZIP:
------------------
Capitulo01_AED/
├── Arreglo/                  ← Proyecto de Arreglos Unidimensionales
│   └── src/
│       └── Arreglo/
│           ├── Arreglo.java
│           └── AplicaArreglo.java
│
├── CMatriz/                  ← Proyecto de Arreglos Bidimensionales (Matrices)
│   └── src/
│       └── clases/
│           ├── CMatriz.java
│           └── AplicaMatriz.java
│
└── README.txt                ← Este archivo


CÓMO ABRIR EN APACHE NETBEANS
=============================

OPCIÓN RECOMENDADA (más fácil):

1. Abre Apache NetBeans.
2. Ve a:  File → New Project → Java → Java Application → Next
3. En "Project Name" escribe:  Arreglo
4. Quita la marca de "Create Main Class" (desmárcala)
5. Finish

6. Ahora crea el paquete:
   - Clic derecho en "Source Packages" → New → Java Package
   - Nombre del paquete:  Arreglo
   - Finish

7. Copia los dos archivos .java (Arreglo.java y AplicaArreglo.java)
   dentro de la carpeta del paquete Arreglo.

8. Clic derecho en AplicaArreglo.java → Run File

Repite el mismo proceso para el proyecto CMatriz:
- Nombre del proyecto: CMatriz
- Nombre del paquete: clases
- Clase principal: AplicaMatriz.java


OPCIÓN ALTERNATIVA (Importar proyecto):

1. File → Open Project
2. Busca la carpeta Arreglo o CMatriz
3. Si NetBeans no lo reconoce como proyecto, usa la opción anterior.


RESUMEN DE LO QUE HACE CADA PROYECTO
====================================

PROYECTO "Arreglo" (Unidimensional)
-----------------------------------
Menú completo con:
 1. Crear el arreglo
 2. Ingresar datos
 3. Mostrar datos
 4. Suma de pares
 5. Primer par al final
 6. Eliminar un elemento          ← Actividad 1
 7. Modificar un elemento         ← Actividad 1
 8. Insertar elemento en posición ← Actividad 1
 9. Sumar todos los elementos     ← Actividad 1
10. Menor, Mayor y Promedio       ← Actividad 1
11. Suma de impares               ← Actividad 1
12. Mover primer elemento al final← Actividad 1
13. ACTIVIDAD 2: Notas de prácticas (elimina la más baja y calcula promedio redondeado)


PROYECTO "CMatriz" (Bidimensional)
----------------------------------
Menú completo con:
 1. Crear matriz
 2. Ingresar datos
 3. Mostrar datos
 4. Suma de elementos
 5. Eliminar última columna
 6. Eliminar un elemento          ← Actividad 2
 7. Modificar un elemento         ← Actividad 2
 8. Menor, Mayor y Promedio       ← Actividad 2
 9. Suma letra L                  ← Actividad 2
10. Suma letra J                  ← Actividad 2
11. Suma letra U                  ← Actividad 2
12. Menor de cada fila            ← Actividad 2
13. Contar números pares          ← Actividad 2
14. Mover filas a la derecha      ← Actividad 2


¡Éxito con el laboratorio!
================================================================================
