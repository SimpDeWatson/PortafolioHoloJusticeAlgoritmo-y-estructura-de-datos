package clases;

import java.util.Scanner;

public class AplicaMatriz {

    static CMatriz objArreglo = new CMatriz();
    static Scanner teclado = new Scanner(System.in);

    public static void main(String[] args) {
        menu();
    }

    static void menu() {
        int opcion, fila, columna;
        do {
            System.out.println("\n========== MENÚ DE OPCIONES ==========");
            System.out.println("1.- Crear el Arreglo (Matriz)");
            System.out.println("2.- Ingresar Datos");
            System.out.println("3.- Mostrar Datos");
            System.out.println("4.- Suma de Elementos");
            System.out.println("5.- Eliminar la última Columna");
            System.out.println("--------------------------------------");
            System.out.println("6.- Eliminar un elemento");
            System.out.println("7.- Modificar un elemento");
            System.out.println("8.- Menor, Mayor y Promedio");
            System.out.println("9.- Suma letra L");
            System.out.println("10.- Suma letra J");
            System.out.println("11.- Suma letra U");
            System.out.println("12.- Menor de cada fila");
            System.out.println("13.- Contar números pares");
            System.out.println("14.- Mover filas una posición a la derecha");
            System.out.println("0.- Salir");
            System.out.println("======================================");
            System.out.print("Ingrese una alternativa: ");
            opcion = teclado.nextInt();
            System.out.println();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese tamaño de la Fila: ");
                    fila = teclado.nextInt();
                    System.out.print("Ingrese tamaño de la Columna: ");
                    columna = teclado.nextInt();
                    objArreglo.creaArreglo(fila, columna);
                    System.out.println("Matriz creada de " + fila + " x " + columna);
                    break;
                case 2:
                    objArreglo.leerNumero();
                    break;
                case 3:
                    objArreglo.listado();
                    break;
                case 4:
                    objArreglo.suma();
                    break;
                case 5:
                    objArreglo.eliminaUltimaColumna();
                    break;
                case 6:
                    System.out.print("Ingrese el elemento a eliminar: ");
                    int elim = teclado.nextInt();
                    objArreglo.eliminar(elim);
                    break;
                case 7:
                    System.out.print("Ingrese el elemento a modificar: ");
                    int viejo = teclado.nextInt();
                    System.out.print("Ingrese el nuevo valor: ");
                    int nuevo = teclado.nextInt();
                    objArreglo.modificar(viejo, nuevo);
                    break;
                case 8:
                    objArreglo.menorMayorPromedio();
                    break;
                case 9:
                    objArreglo.sumaLetraL();
                    break;
                case 10:
                    objArreglo.sumaLetraJ();
                    break;
                case 11:
                    objArreglo.sumaLetraU();
                    break;
                case 12:
                    objArreglo.menorPorFila();
                    break;
                case 13:
                    objArreglo.contarPares();
                    break;
                case 14:
                    objArreglo.moverFilasDerecha();
                    break;
                case 0:
                    System.out.println("¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida. Ingrese otra opción.");
            }
        } while (opcion != 0);
    }
}