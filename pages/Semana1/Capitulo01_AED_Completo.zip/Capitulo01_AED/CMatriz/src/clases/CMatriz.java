package clases;

import java.util.Scanner;

public class CMatriz {

    static int[][] matriz;
    static int fila, columna;
    static Scanner teclado = new Scanner(System.in);

    public CMatriz() {
        // Constructor vacío
    }

    // Crear la matriz
    public void creaArreglo(int fil, int col) {
        matriz = new int[fil][col];
        fila = fil;
        columna = col;
    }

    // Ingresar un número
    public int getNumero() {
        int valor;
        System.out.print("Ingrese un Número: ");
        valor = teclado.nextInt();
        return valor;
    }

    // Leer todos los números de la matriz
    public void leerNumero() {
        for (int i = 0; i < fila; i++) {
            for (int j = 0; j < columna; j++) {
                System.out.print("Posición [" + i + "][" + j + "]: ");
                matriz[i][j] = getNumero();
            }
        }
    }

    // Listar los elementos
    public void listado() {
        System.out.println("Listado Elementos");
        System.out.println("=================");
        if (fila > 0 && columna > 0) {
            for (int i = 0; i < fila; i++) {
                for (int j = 0; j < columna; j++) {
                    System.out.print(matriz[i][j] + "\t");
                }
                System.out.println();
            }
        } else {
            System.out.println("No Existen Elementos");
        }
    }

    // Suma de todos los elementos
    public void suma() {
        int suma = 0;
        if (fila > 0 && columna > 0) {
            for (int i = 0; i < fila; i++) {
                for (int j = 0; j < columna; j++) {
                    suma += matriz[i][j];
                }
            }
            System.out.println("La suma es: " + suma);
        } else {
            System.out.println("No Existe Elementos");
        }
    }

    // Eliminar la última columna
    public void eliminaUltimaColumna() {
        if (fila > 0 && columna > 0) {
            if (columna == 1) {
                // Si solo queda 1 columna, se elimina todo
                columna = 0;
                fila = 0;
            } else {
                columna = columna - 1;
            }
            listado();
        }
    }

    // ========== ACTIVIDAD 2 - MÉTODOS ADICIONALES ==========

    // 1. Eliminar un elemento "x" (primera ocurrencia)
    public void eliminar(int x) {
        boolean encontrado = false;
        for (int i = 0; i < fila; i++) {
            for (int j = 0; j < columna; j++) {
                if (matriz[i][j] == x) {
                    // Desplazar a la izquierda el resto de la fila
                    for (int k = j; k < columna - 1; k++) {
                        matriz[i][k] = matriz[i][k + 1];
                    }
                    matriz[i][columna - 1] = 0; // opcional: poner 0 al final
                    encontrado = true;
                    System.out.println("Elemento " + x + " eliminado de la posición [" + i + "][" + j + "]");
                    break;
                }
            }
            if (encontrado) break;
        }
        if (!encontrado) {
            System.out.println("El elemento " + x + " no se encontró en la matriz.");
        } else {
            listado();
        }
    }

    // 2. Modificar un elemento "x"
    public void modificar(int x, int nuevo) {
        boolean encontrado = false;
        for (int i = 0; i < fila; i++) {
            for (int j = 0; j < columna; j++) {
                if (matriz[i][j] == x) {
                    matriz[i][j] = nuevo;
                    encontrado = true;
                    System.out.println("Elemento modificado en [" + i + "][" + j + "]");
                    break;
                }
            }
            if (encontrado) break;
        }
        if (!encontrado) {
            System.out.println("El elemento " + x + " no se encontró.");
        } else {
            listado();
        }
    }

    // 3. Sumar todos los elementos (ya existe el método suma())

    // 4. Hallar el número menor, el mayor y el promedio
    public void menorMayorPromedio() {
        if (fila == 0 || columna == 0) {
            System.out.println("La matriz está vacía.");
            return;
        }
        int menor = matriz[0][0];
        int mayor = matriz[0][0];
        int suma = 0;
        int total = fila * columna;

        for (int i = 0; i < fila; i++) {
            for (int j = 0; j < columna; j++) {
                if (matriz[i][j] < menor) menor = matriz[i][j];
                if (matriz[i][j] > mayor) mayor = matriz[i][j];
                suma += matriz[i][j];
            }
        }
        double promedio = (double) suma / total;
        System.out.println("Número menor: " + menor);
        System.out.println("Número mayor: " + mayor);
        System.out.println("Promedio: " + String.format("%.2f", promedio));
    }

    // 5. Suma de los elementos que forman la letra L
    // L = primera columna completa + última fila (excepto el elemento que ya está en la esquina)
    public void sumaLetraL() {
        if (fila == 0 || columna == 0) {
            System.out.println("La matriz está vacía.");
            return;
        }
        int suma = 0;
        // Primera columna
        for (int i = 0; i < fila; i++) {
            suma += matriz[i][0];
        }
        // Última fila (desde la columna 1)
        for (int j = 1; j < columna; j++) {
            suma += matriz[fila - 1][j];
        }
        System.out.println("Suma de los elementos que forman la letra L: " + suma);
    }

    // 6. Suma de los elementos que forman la letra J
    // J = última columna completa + última fila (excepto el elemento de la esquina)
    public void sumaLetraJ() {
        if (fila == 0 || columna == 0) {
            System.out.println("La matriz está vacía.");
            return;
        }
        int suma = 0;
        // Última columna
        for (int i = 0; i < fila; i++) {
            suma += matriz[i][columna - 1];
        }
        // Última fila (desde la columna 0 hasta columna-2)
        for (int j = 0; j < columna - 1; j++) {
            suma += matriz[fila - 1][j];
        }
        System.out.println("Suma de los elementos que forman la letra J: " + suma);
    }

    // 7. Suma de los elementos que forman la letra U
    // U = primera columna + última columna + última fila (sin repetir las esquinas)
    public void sumaLetraU() {
        if (fila == 0 || columna == 0) {
            System.out.println("La matriz está vacía.");
            return;
        }
        int suma = 0;
        // Primera columna
        for (int i = 0; i < fila; i++) {
            suma += matriz[i][0];
        }
        // Última columna (si hay más de 1 columna)
        if (columna > 1) {
            for (int i = 0; i < fila; i++) {
                suma += matriz[i][columna - 1];
            }
        }
        // Última fila (columnas intermedias)
        for (int j = 1; j < columna - 1; j++) {
            suma += matriz[fila - 1][j];
        }
        System.out.println("Suma de los elementos que forman la letra U: " + suma);
    }

    // 8. Visualizar el menor número de cada fila
    public void menorPorFila() {
        if (fila == 0 || columna == 0) {
            System.out.println("La matriz está vacía.");
            return;
        }
        System.out.println("Menor de cada fila:");
        for (int i = 0; i < fila; i++) {
            int menor = matriz[i][0];
            for (int j = 1; j < columna; j++) {
                if (matriz[i][j] < menor) {
                    menor = matriz[i][j];
                }
            }
            System.out.println("Fila " + i + " → menor = " + menor);
        }
    }

    // 9. Contar los números pares
    public void contarPares() {
        if (fila == 0 || columna == 0) {
            System.out.println("La matriz está vacía.");
            return;
        }
        int contador = 0;
        for (int i = 0; i < fila; i++) {
            for (int j = 0; j < columna; j++) {
                if (matriz[i][j] % 2 == 0) {
                    contador++;
                }
            }
        }
        System.out.println("Cantidad de números pares: " + contador);
    }

    // 10. Mover los contenidos de las filas una posición a la derecha
    // El último elemento de cada fila pasa a la primera posición
    public void moverFilasDerecha() {
        if (fila == 0 || columna <= 1) {
            System.out.println("No se puede realizar el movimiento.");
            return;
        }
        for (int i = 0; i < fila; i++) {
            int ultimo = matriz[i][columna - 1];
            for (int j = columna - 1; j > 0; j--) {
                matriz[i][j] = matriz[i][j - 1];
            }
            matriz[i][0] = ultimo;
        }
        System.out.println("Filas movidas una posición a la derecha.");
        listado();
    }
}