package Arreglo;

import java.util.Scanner;

public class Arreglo {

    static int[] numerito;
    static int tope = 0;
    static Scanner teclado = new Scanner(System.in);

    public Arreglo() {
        // Constructor vacío
    }

    // Crea el arreglo con el tamaño indicado
    public void creaArreglo(int valor) {
        numerito = new int[valor];
        tope = 0;
    }

    // Ingresa un número por teclado
    public int getNumero() {
        int valor;
        System.out.print("Ingrese un Número: ");
        valor = teclado.nextInt();
        return valor;
    }

    // Lectura de datos (ingresa elementos uno por uno)
    public void lectura() {
        if (tope < numerito.length) {
            numerito[tope] = getNumero();
            tope++;
        } else {
            System.out.println("El arreglo está lleno.");
        }
    }

    // Muestra los elementos del arreglo
    public void escritura() {
        System.out.println("\tListado");
        System.out.println("\t=======");
        if (tope > 0) {
            for (int i = 0; i < tope; i++) {
                System.out.print(numerito[i] + "\t");
            }
            System.out.println("\n");
        } else {
            System.out.println("No existen elementos");
        }
    }

    // Suma de números pares
    public void sumaPares() {
        int suma = 0;
        for (int i = 0; i < tope; i++) {
            if (numerito[i] % 2 == 0) {
                suma = suma + numerito[i];
            }
        }
        System.out.println("La Suma de Pares es: " + suma);
    }

    // Mueve el primer número par al final
    public void primerParAlFinal() {
        if (tope > 0) {
            for (int i = 0; i < tope - 1; i++) {
                if (numerito[i] % 2 == 0) {
                    int aux = numerito[i];
                    numerito[i] = numerito[tope - 1];
                    numerito[tope - 1] = aux;
                    break;
                }
            }
            escritura();
        }
    }

    // ========== ACTIVIDAD 1 ==========

    // 1. Eliminar un elemento "x"
    public void eliminar(int x) {
        if (tope == 0) {
            System.out.println("El arreglo está vacío.");
            return;
        }
        int pos = -1;
        for (int i = 0; i < tope; i++) {
            if (numerito[i] == x) {
                pos = i;
                break;
            }
        }
        if (pos == -1) {
            System.out.println("El elemento " + x + " no existe en el arreglo.");
            return;
        }
        for (int i = pos; i < tope - 1; i++) {
            numerito[i] = numerito[i + 1];
        }
        tope--;
        System.out.println("Elemento " + x + " eliminado correctamente.");
        escritura();
    }

    // 2. Modificar un elemento "x"
    public void modificar(int x, int nuevo) {
        if (tope == 0) {
            System.out.println("El arreglo está vacío.");
            return;
        }
        boolean encontrado = false;
        for (int i = 0; i < tope; i++) {
            if (numerito[i] == x) {
                numerito[i] = nuevo;
                encontrado = true;
                break;
            }
        }
        if (encontrado) {
            System.out.println("Elemento modificado correctamente.");
            escritura();
        } else {
            System.out.println("El elemento " + x + " no existe en el arreglo.");
        }
    }

    // 3. Insertar un elemento "x" en la posición "y"
    public void insertar(int x, int y) {
        if (tope >= numerito.length) {
            System.out.println("El arreglo está lleno. No se puede insertar.");
            return;
        }
        if (y < 0 || y > tope) {
            System.out.println("Posición inválida. Debe estar entre 0 y " + tope);
            return;
        }
        for (int i = tope; i > y; i--) {
            numerito[i] = numerito[i - 1];
        }
        numerito[y] = x;
        tope++;
        System.out.println("Elemento " + x + " insertado en la posición " + y);
        escritura();
    }

    // 4. Sumar todos los elementos del arreglo
    public void sumarTodos() {
        if (tope == 0) {
            System.out.println("El arreglo está vacío.");
            return;
        }
        int suma = 0;
        for (int i = 0; i < tope; i++) {
            suma += numerito[i];
        }
        System.out.println("La suma de todos los elementos es: " + suma);
    }

    // 5. Hallar el número menor, el mayor y el promedio
    public void menorMayorPromedio() {
        if (tope == 0) {
            System.out.println("El arreglo está vacío.");
            return;
        }
        int menor = numerito[0];
        int mayor = numerito[0];
        int suma = 0;
        for (int i = 0; i < tope; i++) {
            if (numerito[i] < menor) {
                menor = numerito[i];
            }
            if (numerito[i] > mayor) {
                mayor = numerito[i];
            }
            suma += numerito[i];
        }
        double promedio = (double) suma / tope;
        System.out.println("Número menor: " + menor);
        System.out.println("Número mayor: " + mayor);
        System.out.println("Promedio: " + String.format("%.2f", promedio));
    }

    // 6. Suma de números impares
    public void sumaImpares() {
        int suma = 0;
        for (int i = 0; i < tope; i++) {
            if (numerito[i] % 2 != 0) {
                suma += numerito[i];
            }
        }
        System.out.println("La Suma de Impares es: " + suma);
    }

    // 7. Mover el primer elemento a la última posición
    public void primerAlFinal() {
        if (tope <= 1) {
            System.out.println("No hay suficientes elementos para mover.");
            return;
        }
        int aux = numerito[0];
        for (int i = 0; i < tope - 1; i++) {
            numerito[i] = numerito[i + 1];
        }
        numerito[tope - 1] = aux;
        System.out.println("Primer elemento movido al final.");
        escritura();
    }

    // 8. Mover el primer número par al final (ya existe, se mantiene)
}