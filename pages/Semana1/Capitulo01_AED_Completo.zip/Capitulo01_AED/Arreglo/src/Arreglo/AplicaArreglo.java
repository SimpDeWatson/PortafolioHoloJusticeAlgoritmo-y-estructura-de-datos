package Arreglo;

import java.util.Scanner;

public class AplicaArreglo {

    static Arreglo objArreglo = new Arreglo();
    static Scanner teclado = new Scanner(System.in);

    public static void main(String[] args) {
        menu();
    }

    static void menu() {
        int opcion, tam;
        do {
            System.out.println("\n========== MENÚ DE OPCIONES ==========");
            System.out.println("1.- Crear el Arreglo");
            System.out.println("2.- Ingresar Datos");
            System.out.println("3.- Mostrar Datos");
            System.out.println("4.- Suma de Pares");
            System.out.println("5.- Primer Par al Final");
            System.out.println("--------------------------------------");
            System.out.println("6.- Eliminar un elemento");
            System.out.println("7.- Modificar un elemento");
            System.out.println("8.- Insertar un elemento en posición");
            System.out.println("9.- Sumar todos los elementos");
            System.out.println("10.- Menor, Mayor y Promedio");
            System.out.println("11.- Suma de Impares");
            System.out.println("12.- Mover primer elemento al final");
            System.out.println("--------------------------------------");
            System.out.println("13.- ACTIVIDAD 2: Notas de Prácticas");
            System.out.println("0.- Salir");
            System.out.println("======================================");
            System.out.print("Ingrese una alternativa: ");
            opcion = teclado.nextInt();
            System.out.println();

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese tamaño del Arreglo: ");
                    tam = teclado.nextInt();
                    objArreglo.creaArreglo(tam);
                    System.out.println("Arreglo creado con tamaño " + tam);
                    break;
                case 2:
                    objArreglo.lectura();
                    break;
                case 3:
                    objArreglo.escritura();
                    break;
                case 4:
                    objArreglo.sumaPares();
                    break;
                case 5:
                    objArreglo.primerParAlFinal();
                    break;
                case 6:
                    System.out.print("Ingrese el elemento a eliminar: ");
                    int elim = teclado.nextInt();
                    objArreglo.eliminar(elim);
                    break;
                case 7:
                    System.out.print("Ingrese el elemento a modificar: ");
                    int viejo = teclado.nextInt();
                    System.out.print("Ingrese el nuevo valor: ");
                    int nuevo = teclado.nextInt();
                    objArreglo.modificar(viejo, nuevo);
                    break;
                case 8:
                    System.out.print("Ingrese el elemento a insertar: ");
                    int valor = teclado.nextInt();
                    System.out.print("Ingrese la posición (0 a " + (Arreglo.tope) + "): ");
                    int pos = teclado.nextInt();
                    objArreglo.insertar(valor, pos);
                    break;
                case 9:
                    objArreglo.sumarTodos();
                    break;
                case 10:
                    objArreglo.menorMayorPromedio();
                    break;
                case 11:
                    objArreglo.sumaImpares();
                    break;
                case 12:
                    objArreglo.primerAlFinal();
                    break;
                case 13:
                    actividad2Notas();
                    break;
                case 0:
                    System.out.println("¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 0);
    }

    // ========== ACTIVIDAD 2 ==========
    // Ingresar notas de prácticas, eliminar la más baja, calcular promedio redondeado
    static void actividad2Notas() {
        System.out.println("===== ACTIVIDAD 2: Notas de Prácticas =====");
        System.out.print("¿Cuántas notas de prácticas desea ingresar?: ");
        int n = teclado.nextInt();

        if (n <= 0) {
            System.out.println("Debe ingresar al menos 1 nota.");
            return;
        }

        double[] notas = new double[n];
        double suma = 0;
        double menor = Double.MAX_VALUE;

        for (int i = 0; i < n; i++) {
            double nota;
            do {
                System.out.print("Ingrese nota de práctica " + (i + 1) + " (0-20): ");
                nota = teclado.nextDouble();
                if (nota < 0 || nota > 20) {
                    System.out.println("Nota inválida. Debe estar entre 0 y 20.");
                }
            } while (nota < 0 || nota > 20);

            notas[i] = nota;
            suma += nota;
            if (nota < menor) {
                menor = nota;
            }
        }

        // Se elimina la nota más baja
        suma = suma - menor;
        double promedio = suma / (n - 1);

        // Promedio redondeado
        long promedioRedondeado = Math.round(promedio);

        System.out.println("\n----- RESULTADOS -----");
        System.out.print("Notas ingresadas: ");
        for (double nota : notas) {
            System.out.print(nota + "  ");
        }
        System.out.println("\nNota más baja eliminada: " + menor);
        System.out.println("Promedio (sin la más baja): " + String.format("%.2f", promedio));
        System.out.println("Promedio redondeado: " + promedioRedondeado);
        System.out.println("----------------------");
    }
}